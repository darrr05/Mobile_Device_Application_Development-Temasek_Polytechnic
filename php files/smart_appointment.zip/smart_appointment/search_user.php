<?php
require_once __DIR__ . "/db_connect.php";
$data = json_decode(file_get_contents("php://input"), true);

$username = trim($data["username"] ?? "");
$user_id  = intval($data["user_id"] ?? 0);

$conn = (new DB_CONNECT())->connect();

$stmt = $conn->prepare(
    "SELECT id, username FROM users
     WHERE username = ? AND id != ?"
);
$stmt->bind_param("si", $username, $user_id);
$stmt->execute();
$res = $stmt->get_result();

if ($row = $res->fetch_assoc()) {
    echo json_encode(["success"=>1, "user"=>$row]);
} else {
    echo json_encode(["success"=>0, "message"=>"User not found"]);
}
