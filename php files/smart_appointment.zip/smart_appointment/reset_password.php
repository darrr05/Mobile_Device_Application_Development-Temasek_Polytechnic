<?php
date_default_timezone_set("Asia/Singapore");
header("Content-Type: application/json; charset=UTF-8");

require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);
$email = strtolower(trim($data["email"] ?? ""));
$token = trim($data["reset_token"] ?? "");
$new_password = strval($data["new_password"] ?? "");

if ($email === "" || $token === "" || $new_password === "") {
    echo json_encode(["success" => 0, "message" => "Invalid request"]);
    exit;
}

if (strlen($new_password) < 8) {
    echo json_encode(["success" => 0, "message" => "Password too short"]);
    exit;
}

$conn = (new DB_CONNECT())->connect();

$stmt = $conn->prepare("SELECT id, google_id, password_hash FROM users WHERE LOWER(email)=? LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    echo json_encode(["success" => 0, "message" => "Account not found"]);
    exit;
}

if (!empty($user["google_id"]) || empty($user["password_hash"])) {
    echo json_encode(["success" => 0, "message" => "Google users cannot reset password"]);
    exit;
}

$user_id = intval($user["id"]);

$now = date("Y-m-d H:i:s");
$t = $conn->prepare(
    "SELECT id, token_hash
     FROM password_reset_tokens
     WHERE user_id=? AND expires_at>?
     ORDER BY id DESC
     LIMIT 1"
);
$t->bind_param("is", $user_id, $now);
$t->execute();
$tokenRow = $t->get_result()->fetch_assoc();

if (!$tokenRow || !password_verify($token, $tokenRow["token_hash"])) {
    echo json_encode(["success" => 0, "message" => "Invalid or expired reset token"]);
    exit;
}

$new_hash = password_hash($new_password, PASSWORD_DEFAULT);

$up = $conn->prepare("UPDATE users SET password_hash=? WHERE id=?");
$up->bind_param("si", $new_hash, $user_id);
$up->execute();

$del = $conn->prepare("DELETE FROM password_reset_tokens WHERE user_id=?");
$del->bind_param("i", $user_id);
$del->execute();

echo json_encode(["success" => 1]);
exit;
