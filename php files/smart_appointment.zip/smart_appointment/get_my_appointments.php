<?php
header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);
$user_id = intval($data["user_id"] ?? 0);

if ($user_id <= 0) {
    echo json_encode([
        "success" => 0,
        "message" => "Invalid user"
    ]);
    exit;
}

$conn = (new DB_CONNECT())->connect();

/*
  ✅ Return appointments where user is owner OR participant
  ✅ Correct column names
*/
$sql = "
SELECT 
    a.id,
    a.title,
    a.appt_date,
    a.appt_time,
    a.location,
    a.notes,
    a.notify,
    a.email,
    a.whatsapp
FROM appointments a
JOIN appointment_participants ap
    ON ap.appointment_id = a.id
WHERE ap.user_id = ?
ORDER BY a.appt_date, a.appt_time
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();

$res = $stmt->get_result();
$list = [];

while ($row = $res->fetch_assoc()) {
    $list[] = $row;
}

echo json_encode([
    "success" => 1,
    "data" => $list
]);
