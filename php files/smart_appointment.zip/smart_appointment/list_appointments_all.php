<?php
header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

$db = new DB_CONNECT();
$conn = $db->connect();

$res = $conn->query("SELECT * FROM appointments");

$appts = [];
while ($row = $res->fetch_assoc()) {
    $appts[] = $row;
}

echo json_encode([
    "success" => 1,
    "appointments" => $appts
]);