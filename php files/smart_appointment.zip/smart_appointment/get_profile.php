<?php
header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);
$user_id = intval($data["user_id"] ?? 0);

if ($user_id <= 0) {
    echo json_encode(["success" => 0, "message" => "Invalid user"]);
    exit;
}

$conn = (new DB_CONNECT())->connect();

$stmt = $conn->prepare(
    "SELECT
        username,
        email,
        phone,
        email_verified,
        phone_verified,
        created_at
     FROM users
     WHERE id = ?"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    echo json_encode([
        "success" => 1,
        "data" => $row
    ]);
} else {
    echo json_encode([
        "success" => 0,
        "message" => "User not found"
    ]);
}
