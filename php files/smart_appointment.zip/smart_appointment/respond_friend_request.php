<?php
require_once __DIR__ . "/db_connect.php";
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);

$request_id = intval($data["request_id"] ?? 0);
$action     = strtolower($data["action"] ?? "");

if ($request_id <= 0 || !in_array($action, ["accept", "reject"])) {
    echo json_encode(["success" => 0, "message" => "Invalid request"]);
    exit;
}

$conn = (new DB_CONNECT())->connect();

/* 🔍 Get request (LOWERCASE STATUS) */
$stmt = $conn->prepare(
    "SELECT sender_id, receiver_id
     FROM friend_requests
     WHERE id = ? AND status = 'pending'"
);
$stmt->bind_param("i", $request_id);
$stmt->execute();

$row = $stmt->get_result()->fetch_assoc();

if (!$row) {
    echo json_encode(["success" => 0, "message" => "Request not found"]);
    exit;
}

$sender   = $row["sender_id"];
$receiver = $row["receiver_id"];

if ($action === "accept") {

    /* ✅ Insert BOTH directions */
    $insert = $conn->prepare(
        "INSERT IGNORE INTO friends (user_id, friend_id)
         VALUES (?, ?), (?, ?)"
    );
    $insert->bind_param(
        "iiii",
        $sender, $receiver,
        $receiver, $sender
    );
    $insert->execute();

    $status = "accepted";

} else {
    $status = "rejected";
}

/* ✅ Update request status (LOWERCASE) */
$update = $conn->prepare(
    "UPDATE friend_requests SET status = ? WHERE id = ?"
);
$update->bind_param("si", $status, $request_id);
$update->execute();

echo json_encode([
    "success" => 1,
    "status"  => $status
]);
