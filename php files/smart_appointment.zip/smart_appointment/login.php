<?php
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);

$input = trim($data["email"] ?? "");
$password = $data["password"] ?? "";

if ($input === "" || $password === "") {
    echo json_encode(["success" => 0, "message" => "Missing fields"]);
    exit;
}

require_once __DIR__ . "/db_connect.php";
$db = new DB_CONNECT();
$conn = $db->connect();

$stmt = $conn->prepare(
    "SELECT id, username, email, phone, password_hash, created_at
     FROM users
     WHERE email = ? OR username = ?"
);

// ✅ FIX: bind BOTH placeholders
$stmt->bind_param("ss", $input, $input);

$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    if (!empty($row["password_hash"]) &&
        password_verify($password, $row["password_hash"])) {

        echo json_encode([
            "success"     => 1,
            "user_id"     => $row["id"],
            "username"    => $row["username"],
            "email"       => $row["email"],
            "phone"       => $row["phone"],
            "created_at"  => $row["created_at"]
        ]);
        exit;
    }
}

echo json_encode(["success" => 0, "message" => "Invalid login"]);
