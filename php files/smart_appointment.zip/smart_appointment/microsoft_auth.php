<?php
require_once "db_connect.php";
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);

$email = $data["email"] ?? "";
$microsoft_id = $data["microsoft_id"] ?? "";

if ($email === "" || $microsoft_id === "") {
    echo json_encode(["success" => 0, "message" => "Invalid data"]);
    exit;
}

$db = new DB_CONNECT();
$conn = $db->connect();

/* 1️⃣ Check existing user */
$stmt = $conn->prepare(
    "SELECT user_id, username, email
     FROM users
     WHERE email = ? OR microsoft_id = ?"
);
$stmt->bind_param("ss", $email, $microsoft_id);
$stmt->execute();
$res = $stmt->get_result();

if ($row = $res->fetch_assoc()) {

    /* Existing user → login */
    echo json_encode([
        "success" => 1,
        "user_id" => $row["user_id"],
        "username" => $row["username"],
        "email" => $row["email"]
    ]);
    exit;
}

/* 2️⃣ Auto-register */
$username = explode("@", $email)[0];

$stmt = $conn->prepare(
    "INSERT INTO users (username, email, microsoft_id, email_verified)
     VALUES (?, ?, ?, 1)"
);
$stmt->bind_param("sss", $username, $email, $microsoft_id);

if ($stmt->execute()) {

    echo json_encode([
        "success" => 1,
        "user_id" => $stmt->insert_id,
        "username" => $username,
        "email" => $email
    ]);

} else {
    echo json_encode([
        "success" => 0,
        "message" => "Registration failed"
    ]);
}
