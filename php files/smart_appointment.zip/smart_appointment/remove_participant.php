<?php
header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);

$appointment_id = intval($data["appointment_id"] ?? 0);
$user_id = intval($data["user_id"] ?? 0);

if ($appointment_id <= 0 || $user_id <= 0) {
    echo json_encode(["success" => 0]);
    exit;
}

$conn = (new DB_CONNECT())->connect();

$stmt = $conn->prepare(
    "DELETE FROM appointment_participants
     WHERE appointment_id = ?
     AND user_id = ?
     AND role = 'participant'"
);

$stmt->bind_param("ii", $appointment_id, $user_id);
$stmt->execute();

echo json_encode(["success" => 1]);
