<?php
header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

/* ================= READ INPUT ================= */
$data = json_decode(file_get_contents("php://input"), true);
$user_id = intval($data["user_id"] ?? 0);

if ($user_id <= 0) {
    echo json_encode([
        "success" => 0,
        "message" => "Invalid user"
    ]);
    exit;
}

/* 🔍 DEBUG: confirm correct user ID */
error_log("DELETE PROFILE API called for user_id = $user_id");

/* ================= DB + TRANSACTION ================= */
$conn = (new DB_CONNECT())->connect();
$conn->begin_transaction();

try {

    /* ================= VERIFY USER EXISTS ================= */
    $stmt = $conn->prepare(
        "SELECT email, phone FROM users WHERE id = ?"
    );
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 0) {
        throw new Exception("User not found");
    }

    $user  = $res->fetch_assoc();
    $email = $user["email"];
    $phone = $user["phone"];

    /* ================= DELETE PARTICIPANT ENTRIES ================= */
    $stmt = $conn->prepare(
        "DELETE FROM appointment_participants
         WHERE user_id = ?"
    );
    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    /* ================= DELETE PARTICIPANTS FOR USER'S APPOINTMENTS ================= */
    $stmt = $conn->prepare(
        "DELETE ap
         FROM appointment_participants ap
         JOIN appointments a ON ap.appointment_id = a.id
         WHERE a.user_id = ?"
    );
    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    /* ================= DELETE USER'S APPOINTMENTS ================= */
    $stmt = $conn->prepare(
        "DELETE FROM appointments WHERE user_id = ?"
    );
    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    /* ================= DELETE FRIEND REQUESTS FIRST ================= */
    $stmt = $conn->prepare(
        "DELETE FROM friend_requests
         WHERE sender_id = ? OR receiver_id = ?"
    );
    $stmt->bind_param("ii", $user_id, $user_id);
    $stmt->execute();
    error_log("Friend requests deleted: " . $stmt->affected_rows);

    /* ================= DELETE FRIENDSHIPS ================= */
    $stmt = $conn->prepare(
        "DELETE FROM friends
         WHERE user_id = ? OR friend_id = ?"
    );
    $stmt->bind_param("ii", $user_id, $user_id);
    $stmt->execute();
    error_log("Friends deleted: " . $stmt->affected_rows);

    /* ================= DELETE PASSWORD RESET TOKENS ================= */
    $stmt = $conn->prepare(
        "DELETE FROM password_reset_tokens
         WHERE user_id = ?"
    );
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    error_log("Password reset tokens deleted: " . $stmt->affected_rows);

    /* ================= DELETE OTP RECORDS ================= */
    $stmt = $conn->prepare(
        "DELETE FROM otp_verification
         WHERE target = ? OR target = ?"
    );
    $stmt->bind_param("ss", $email, $phone);
    $stmt->execute();

    /* ================= DELETE USER ================= */
    $stmt = $conn->prepare(
        "DELETE FROM users WHERE id = ?"
    );
    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    if ($stmt->affected_rows === 0) {
        throw new Exception("User delete failed");
    }

    /* ================= COMMIT ================= */
    $conn->commit();

    echo json_encode([
        "success" => 1,
        "message" => "User and ALL related data deleted"
    ]);

} catch (Exception $e) {

    /* ================= ROLLBACK ================= */
    $conn->rollback();

    echo json_encode([
        "success" => 0,
        "message" => $e->getMessage()
    ]);
}
