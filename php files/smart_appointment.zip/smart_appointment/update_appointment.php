<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);

$id       = intval($data["id"] ?? 0);
$title    = trim($data["title"] ?? "");
$newDate  = trim($data["appt_date"] ?? "");
$newTime  = trim($data["appt_time"] ?? "");
$location = trim($data["location"] ?? "");
$notes    = trim($data["notes"] ?? "");

$notify   = intval($data["notify"] ?? 1);
$email    = intval($data["email"] ?? 0);
$whatsapp = intval($data["whatsapp"] ?? 0);

if ($id <= 0 || $title === "" || $newDate === "" || $newTime === "") {
    echo json_encode([
        "success" => 0,
        "message" => "Missing fields"
    ]);
    exit;
}

$conn = (new DB_CONNECT())->connect();

// 🔍 fetch existing
$stmt = $conn->prepare(
    "SELECT appt_date, appt_time FROM appointments WHERE id=?"
);
$stmt->bind_param("i", $id);
$stmt->execute();
$current = $stmt->get_result()->fetch_assoc();

if (!$current) {
    echo json_encode([
        "success" => 0,
        "message" => "Appointment not found"
    ]);
    exit;
}

$dateChanged = ($current["appt_date"] !== $newDate);
$timeChanged = ($current["appt_time"] !== $newTime);

if ($dateChanged || $timeChanged) {

    // 🔁 reset sent flags
    $stmt = $conn->prepare(
        "UPDATE appointments
         SET title=?, appt_date=?, appt_time=?, location=?, notes=?,
             notify=?, email=?, whatsapp=?,
             email_sent=0, whatsapp_sent=0
         WHERE id=?"
    );

    $stmt->bind_param(
        "sssssiiii",
        $title,
        $newDate,
        $newTime,
        $location,
        $notes,
        $notify,
        $email,
        $whatsapp,
        $id
    );

} else {

    // ⏱ no reset
    $stmt = $conn->prepare(
        "UPDATE appointments
         SET title=?, location=?, notes=?,
             notify=?, email=?, whatsapp=?
         WHERE id=?"
    );

    $stmt->bind_param(
        "sssiiii",
        $title,
        $location,
        $notes,
        $notify,
        $email,
        $whatsapp,
        $id
    );
}

$ok = $stmt->execute();

echo json_encode([
    "success" => $ok ? 1 : 0
]);
