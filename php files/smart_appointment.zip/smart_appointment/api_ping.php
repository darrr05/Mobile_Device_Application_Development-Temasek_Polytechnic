<?php
header("Content-Type: application/json");

$clientIp = $_SERVER['REMOTE_ADDR'] ?? '';

if ($clientIp === '10.0.2.15') {
    // Android Emulator
    $ip = '10.0.2.2';
} else {
    // Real phone on LAN / hotspot
    $ip = '172.20.10.4'; // your laptop IP
}

echo json_encode([
    "server_ip" => $ip
]);
