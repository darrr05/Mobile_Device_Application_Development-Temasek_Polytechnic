<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
header("Content-Type: application/json");
require_once "db_connect.php";

$db = new DB_CONNECT();
$conn = $db->connect();

$data = json_decode(file_get_contents("php://input"), true);

$email     = trim($data["email"] ?? "");
$username  = trim($data["username"] ?? "");
$google_id = trim($data["google_id"] ?? "");

if ($email === "" || $google_id === "") {
    echo json_encode([
        "success" => 0,
        "message" => "Missing Google data"
    ]);
    exit;
}

/* ================= CHECK EXISTING USER ================= */

$stmt = $conn->prepare(
    "SELECT id, username, email, phone
     FROM users
     WHERE email = ?"
);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {

    /* ✅ AUTO-VERIFY EMAIL FOR GOOGLE USER */
    $update = $conn->prepare(
        "UPDATE users
         SET google_id = ?,
             email_verified = 1
         WHERE email = ?"
    );
    $update->bind_param("ss", $google_id, $email);
    $update->execute();

    echo json_encode([
        "success" => 1,
        "user_id" => $row["id"],
        "username" => $row["username"],
        "email" => $row["email"],
        "phone" => $row["phone"]
    ]);
    exit;
}

/* ================= NEW GOOGLE USER ================= */

$insert = $conn->prepare(
    "INSERT INTO users
     (username, email, google_id, email_verified, phone_verified, created_at)
     VALUES (?, ?, ?, 1, 0, NOW())"
);

$insert->bind_param("sss", $username, $email, $google_id);

if ($insert->execute()) {
    echo json_encode([
        "success" => 1,
        "user_id" => $insert->insert_id,
        "username" => $username,
        "email" => $email,
        "phone" => ""
    ]);
} else {
    echo json_encode([
        "success" => 0,
        "message" => "Database insert failed"
    ]);
}
