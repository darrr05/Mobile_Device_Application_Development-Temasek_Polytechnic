<?php
require_once __DIR__ . "/db_connect.php";
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);

$user_id = intval($data["user_id"] ?? 0);
$conn = (new DB_CONNECT())->connect();

$stmt = $conn->prepare(
    "SELECT fr.id AS request_id,
            u.username,
            fr.status
     FROM friend_requests fr
     JOIN users u ON fr.sender_id = u.id
     WHERE fr.receiver_id = ?
       AND fr.status = 'pending'"
);
$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$rows = [];

while ($row = $result->fetch_assoc()) {
    $rows[] = $row;
}

echo json_encode([
    "success" => 1,
    "data" => $rows
]);
