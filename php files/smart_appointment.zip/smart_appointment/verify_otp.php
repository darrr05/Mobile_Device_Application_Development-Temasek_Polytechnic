<?php
date_default_timezone_set("Asia/Singapore");
header("Content-Type: application/json");

require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);

$type   = trim($data["type"] ?? "");
$target = trim($data["target"] ?? "");
$otp    = trim($data["otp"] ?? "");
$user_id = intval($data["user_id"] ?? 0);

if ($type === "" || $target === "" || $otp === "") {
    echo json_encode(["success" => 0, "message" => "Invalid request"]);
    exit;
}

/* === NORMALIZE (MATCH send_otp.php) === */
if ($type === "email") {
    $target = strtolower($target);
}

if ($type === "phone") {
    $target = str_replace(" ", "", $target);
    if (substr($target, 0, 1) !== "+") {
        $target = "+65" . $target;
    }
}

$conn = (new DB_CONNECT())->connect();
$now  = date("Y-m-d H:i:s");

/* 🔍 STEP 1: FETCH OTP FIRST */
$stmt = $conn->prepare(
    "SELECT id
     FROM otp_verification
     WHERE target = ?
       AND type = ?
       AND otp_code = ?
       AND expires_at > ?"
);
$stmt->bind_param("ssss", $target, $type, $otp, $now);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();

if (!$row) {
    echo json_encode([
        "success" => 0,
        "message" => "Invalid or expired OTP"
    ]);
    exit;
}

$otp_id = (int)$row["id"];

/* ✅ STEP 2: UPDATE USER (NO SUBQUERY) */
if ($type === "email") {
    $stmt2 = $conn->prepare(
        "UPDATE users SET email_verified = 1 WHERE LOWER(email) = ?"
    );
    $stmt2->bind_param("s", $target);
    $stmt2->execute();
}

if ($type === "phone" && $user_id > 0) {
    $stmt2 = $conn->prepare(
        "UPDATE users
         SET phone = ?, phone_verified = 1
         WHERE id = ?"
    );
    $stmt2->bind_param("si", $target, $user_id);
    $stmt2->execute();
}

/* 🧹 STEP 3: DELETE OTP */
$stmt3 = $conn->prepare(
    "DELETE FROM otp_verification WHERE id = ?"
);
$stmt3->bind_param("i", $otp_id);
$stmt3->execute();

echo json_encode(["success" => 1]);
exit;
