<?php
header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);
$user_id = intval($data["user_id"] ?? 0);

if ($user_id <= 0) {
    echo json_encode([
        "success" => 0,
        "message" => "No user_id"
    ]);
    exit;
}

$conn = (new DB_CONNECT())->connect();

$stmt = $conn->prepare(
    "SELECT DISTINCT
        a.id,
        a.title,
        a.appt_date,
        a.appt_time,
        a.location,
        a.notes,
        a.notify,
        a.email,
        a.whatsapp,

        owner.username AS owner_name,

        CASE
            WHEN ap.role = 'owner' THEN 1
            ELSE 0
        END AS is_owner

     FROM appointments a

     JOIN appointment_participants ap
        ON ap.appointment_id = a.id

     JOIN appointment_participants ap_owner
        ON ap_owner.appointment_id = a.id
       AND ap_owner.role = 'owner'

     JOIN users owner
        ON owner.id = ap_owner.user_id

     WHERE ap.user_id = ?

     ORDER BY a.appt_date, a.appt_time"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();

$res = $stmt->get_result();
$appts = [];

while ($row = $res->fetch_assoc()) {
    $appts[] = $row;
}

echo json_encode([
    "success" => 1,
    "appointments" => $appts
]);
