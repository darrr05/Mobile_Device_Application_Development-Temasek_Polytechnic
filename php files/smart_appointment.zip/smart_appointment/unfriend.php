<?php
header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);

$user_id   = intval($data["user_id"] ?? 0);
$friend_id = intval($data["friend_id"] ?? 0);

if ($user_id <= 0 || $friend_id <= 0) {
    echo json_encode(["success" => 0, "message" => "Invalid input"]);
    exit;
}

$conn = (new DB_CONNECT())->connect();
$conn->begin_transaction();

try {

    /* ================= DELETE FRIENDSHIP ================= */
    $stmt = $conn->prepare(
        "DELETE FROM friends
         WHERE (user_id = ? AND friend_id = ?)
            OR (user_id = ? AND friend_id = ?)"
    );
    $stmt->bind_param("iiii", $user_id, $friend_id, $friend_id, $user_id);
    $stmt->execute();

    /* ================= REMOVE FRIEND FROM MY APPOINTMENTS ================= */
    $stmt = $conn->prepare(
        "DELETE ap
         FROM appointment_participants ap
         JOIN appointments a ON ap.appointment_id = a.id
         WHERE a.user_id = ?
           AND ap.user_id = ?
           AND ap.role != 'owner'"
    );
    $stmt->bind_param("ii", $user_id, $friend_id);
    $stmt->execute();

    /* ================= REMOVE ME FROM FRIEND'S APPOINTMENTS ================= */
    $stmt = $conn->prepare(
        "DELETE ap
         FROM appointment_participants ap
         JOIN appointments a ON ap.appointment_id = a.id
         WHERE a.user_id = ?
           AND ap.user_id = ?
           AND ap.role != 'owner'"
    );
    $stmt->bind_param("ii", $friend_id, $user_id);
    $stmt->execute();

    /* ================= REMOVE FRIEND REQUESTS (BOTH DIRECTIONS) ================= */
    $stmt = $conn->prepare(
        "DELETE FROM friend_requests
        WHERE (sender_id = ? AND receiver_id = ?)
            OR (sender_id = ? AND receiver_id = ?)"
    );
    $stmt->bind_param("iiii", $user_id, $friend_id, $friend_id, $user_id);
    $stmt->execute();

    /* ================= COMMIT ================= */
    $conn->commit();

    echo json_encode([
        "success" => 1,
        "message" => "Unfriended and removed from shared appointments"
    ]);

} catch (Exception $e) {

    $conn->rollback();

    echo json_encode([
        "success" => 0,
        "message" => $e->getMessage()
    ]);
}
