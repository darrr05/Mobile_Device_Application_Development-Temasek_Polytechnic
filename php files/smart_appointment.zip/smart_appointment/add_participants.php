<?php
header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);

$appointment_id = intval($data["appointment_id"] ?? 0);
$friends = $data["friends"] ?? [];

if ($appointment_id <= 0 || !is_array($friends)) {
    echo json_encode(["success" => 0, "message" => "Invalid input"]);
    exit;
}

$conn = (new DB_CONNECT())->connect();

$stmt = $conn->prepare(
    "INSERT IGNORE INTO appointment_participants
     (appointment_id, user_id, role)
     VALUES (?, ?, 'participant')"
);

foreach ($friends as $uid) {
    $uid = intval($uid);
    if ($uid <= 0) continue;

    $stmt->bind_param("ii", $appointment_id, $uid);
    $stmt->execute();
}

echo json_encode(["success" => 1]);
