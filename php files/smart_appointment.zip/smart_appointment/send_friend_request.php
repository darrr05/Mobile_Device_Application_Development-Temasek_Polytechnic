<?php
require_once __DIR__ . "/db_connect.php";
$data = json_decode(file_get_contents("php://input"), true);

$sender   = intval($data["sender_id"] ?? 0);
$username = trim($data["receiver_username"] ?? "");

if ($sender <= 0 || $username === "") {
    echo json_encode(["success"=>0,"message"=>"Invalid request"]);
    exit;
}

$conn = (new DB_CONNECT())->connect();

/* =============================
   Get receiver ID
   ============================= */
$stmt = $conn->prepare("SELECT id FROM users WHERE username=?");
$stmt->bind_param("s", $username);
$stmt->execute();
$res = $stmt->get_result();

if (!$row = $res->fetch_assoc()) {
    echo json_encode(["success"=>0,"message"=>"User not found"]);
    exit;
}

$receiver = intval($row["id"]);

if ($sender === $receiver) {
    echo json_encode(["success"=>0,"message"=>"Cannot add yourself"]);
    exit;
}

/* =============================
   Already friends?
   ============================= */
$stmt = $conn->prepare(
    "SELECT 1 FROM friends
     WHERE (user_id=? AND friend_id=?)
        OR (user_id=? AND friend_id=?)"
);
$stmt->bind_param("iiii", $sender, $receiver, $receiver, $sender);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo json_encode(["success"=>0,"message"=>"Already friends"]);
    exit;
}

/* =============================
   Pending request (either way)?
   ============================= */
$stmt = $conn->prepare(
    "SELECT id FROM friend_requests
     WHERE ((sender_id=? AND receiver_id=?)
        OR  (sender_id=? AND receiver_id=?))
       AND status='pending'"
);
$stmt->bind_param("iiii", $sender, $receiver, $receiver, $sender);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo json_encode(["success"=>0,"message"=>"Request already pending"]);
    exit;
}

/* =============================
   Rejected request exists?
   ============================= */
$stmt = $conn->prepare(
    "SELECT id FROM friend_requests
     WHERE sender_id=? AND receiver_id=? AND status='rejected'"
);
$stmt->bind_param("ii", $sender, $receiver);
$stmt->execute();
$res = $stmt->get_result();

if ($row = $res->fetch_assoc()) {
    // Re-send rejected request
    $stmt = $conn->prepare(
        "UPDATE friend_requests
         SET status='pending'
         WHERE id=?"
    );
    $stmt->bind_param("i", $row["id"]);
    $stmt->execute();

    echo json_encode(["success"=>1,"message"=>"Friend request sent"]);
    exit;
}

/* =============================
   Insert new request
   ============================= */
$stmt = $conn->prepare(
    "INSERT INTO friend_requests (sender_id, receiver_id, status)
     VALUES (?, ?, 'pending')"
);
$stmt->bind_param("ii", $sender, $receiver);
$stmt->execute();

echo json_encode(["success"=>1,"message"=>"Friend request sent"]);