<?php
class DB_CONNECT {
    public $myconn;

    public function connect() {
        $this->myconn = new mysqli("localhost", "root", "", "smart_appointment_db");
        if ($this->myconn->connect_error) {
            die("DB connection failed: " . $this->myconn->connect_error);
        }
        $this->myconn->set_charset("utf8mb4");
        return $this->myconn;
    }
}
?>
