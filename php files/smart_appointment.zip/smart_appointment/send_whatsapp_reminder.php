<?php
use Twilio\Rest\Client;

require_once __DIR__ . "/vendor/autoload.php";
require_once __DIR__ . "/db_connect.php";

header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);
$appointment_id = intval($data["appointment_id"] ?? 0);

if ($appointment_id <= 0) {
    echo json_encode(["success" => 0, "error" => "Invalid appointment ID"]);
    exit;
}

$conn = (new DB_CONNECT())->connect();

$stmt = $conn->prepare("
    SELECT 
        u.phone,
        a.title,
        a.location,
        a.notes,
        a.appt_date,
        a.appt_time,
        a.whatsapp_sent
    FROM appointments a
    JOIN users u ON a.user_id = u.id
    WHERE a.id = ?
      AND a.whatsapp = 1
      AND u.phone_verified = 1
");
$stmt->bind_param("i", $appointment_id);
$stmt->execute();

$row = $stmt->get_result()->fetch_assoc();

if (!$row) {
    echo json_encode(["success" => 0, "error" => "Not eligible"]);
    exit;
}

/* 🔒 DEDUPLICATION */
if ($row["whatsapp_sent"] == 1) {
    echo json_encode(["success" => 1, "message" => "WhatsApp already sent"]);
    exit;
}

$time = date("h:i A", strtotime($row["appt_time"]));

/* 📍 GOOGLE MAPS LINK (ADD-ON) */
$mapsLink = "";
if (!empty($row["location"])) {
    $encodedLocation = urlencode($row["location"]);
    $mapsLink = "📍 Location: {$row["location"]}\n"
              . "🗺 https://www.google.com/maps/search/?api=1&query={$encodedLocation}\n";
}

$message =
    "📅 *Appointment Reminder*\n\n" .
    "*{$row["title"]}*\n" .
    "🗓 {$row["appt_date"]}\n" .
    "⏰ {$time}\n\n" .
    $mapsLink .
    ($row["notes"] ? "\n📝 {$row["notes"]}" : "");

try {
    $twilio = new Client(
        "AC6214c8a2a7619732d15da81feec622b9",
        "d1495ef7778373d5f91702e35dab1c80"
    );

    $twilio->messages->create(
        "whatsapp:{$row["phone"]}",
        [
            "from" => "whatsapp:+14155238886",
            "body" => $message
        ]
    );

    /* ✅ MARK AS SENT */
    $update = $conn->prepare(
        "UPDATE appointments SET whatsapp_sent = 1 WHERE id = ?"
    );
    $update->bind_param("i", $appointment_id);
    $update->execute();

    echo json_encode(["success" => 1]);

} catch (Exception $e) {
    echo json_encode([
        "success" => 0,
        "error" => "WhatsApp failed"
    ]);
}
