<?php
header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);

$username = trim($data["username"] ?? "");
$email    = trim($data["email"] ?? "");
$password = $data["password"] ?? "";
$phone    = $data["phone"] ?? null;

$email_verified = intval($data["email_verified"] ?? 0);
$phone_verified = intval($data["phone_verified"] ?? 0);
$google_user    = intval($data["google_user"] ?? 0);

/* ================= BASIC VALIDATION ================= */

if ($username === "") {
    echo json_encode([
        "success" => 0,
        "message" => "Username required"
    ]);
    exit;
}

/* Google users ALWAYS email verified */
if ($google_user === 1) {
    $email_verified = 1;
}

$conn = (new DB_CONNECT())->connect();

/* ================= CHECK USERNAME EXISTS ================= */

$checkUsername = $conn->prepare(
    "SELECT id FROM users WHERE username = ?"
);
$checkUsername->bind_param("s", $username);
$checkUsername->execute();
$checkUsername->store_result();

if ($checkUsername->num_rows > 0) {
    echo json_encode([
        "success" => 0,
        "message" => "username exists"
    ]);
    exit;
}

/* ================= CHECK EMAIL EXISTS (ONLY IF PROVIDED) ================= */

if ($email !== "") {
    $checkEmail = $conn->prepare(
        "SELECT id FROM users WHERE email = ?"
    );
    $checkEmail->bind_param("s", $email);
    $checkEmail->execute();
    $checkEmail->store_result();

    if ($checkEmail->num_rows > 0) {
        echo json_encode([
            "success" => 0,
            "message" => "email exists"
        ]);
        exit;
    }
}

/* ================= PASSWORD HANDLING ================= */

$hash = null;

if ($google_user === 0) {

    if ($password === null || trim($password) === "") {
        echo json_encode([
            "success" => 0,
            "message" => "Password required"
        ]);
        exit;
    }

    if (strlen($password) < 8) {
        echo json_encode([
            "success" => 0,
            "message" => "Password must be at least 8 characters"
        ]);
        exit;
    }

    $hash = password_hash($password, PASSWORD_BCRYPT);
}

/* ================= INSERT USER ================= */

$stmt = $conn->prepare(
    "INSERT INTO users
     (username, email, password_hash, phone, email_verified, phone_verified)
     VALUES (?, ?, ?, ?, ?, ?)"
);

$emailParam = ($email === "") ? null : $email;

$stmt->bind_param(
    "ssssii",
    $username,
    $emailParam,
    $hash,
    $phone,
    $email_verified,
    $phone_verified
);

if ($stmt->execute()) {
    echo json_encode(["success" => 1]);
} else {
    if ($conn->errno === 1062) {
        echo json_encode([
            "success" => 0,
            "message" => "username or email exists"
        ]);
    } else {
        echo json_encode([
            "success" => 0,
            "message" => "Registration failed"
        ]);
    }
}
