<?php
header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);

$sender_id   = intval($data["sender_id"] ?? 0);
$receiver_id = intval($data["receiver_id"] ?? 0);

if ($sender_id <= 0 || $receiver_id <= 0) {
    echo json_encode(["success" => 0]);
    exit;
}

$conn = (new DB_CONNECT())->connect();

$stmt = $conn->prepare(
    "DELETE FROM friend_requests
     WHERE sender_id = ?
       AND receiver_id = ?
       AND status = 'pending'"
);
$stmt->bind_param("ii", $sender_id, $receiver_id);
$stmt->execute();

echo json_encode(["success" => 1]);
