<?php
require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);
$user_id = intval($data["user_id"] ?? 0);

if ($user_id <= 0) {
    echo json_encode(["success"=>0,"count"=>0]);
    exit;
}

/* ✅ FIX: create DB connection */
$conn = (new DB_CONNECT())->connect();

$stmt = $conn->prepare("
    SELECT COUNT(*) AS cnt
    FROM friend_requests
    WHERE receiver_id = ?
      AND status = 'pending'
");
$stmt->bind_param("i", $user_id);
$stmt->execute();

$res = $stmt->get_result()->fetch_assoc();

echo json_encode([
    "success" => 1,
    "count"   => intval($res["cnt"] ?? 0)
]);
