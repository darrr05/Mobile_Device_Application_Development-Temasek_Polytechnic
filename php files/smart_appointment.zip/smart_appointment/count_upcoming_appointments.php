<?php
header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);
$user_id = intval($data["user_id"] ?? 0);

if ($user_id <= 0) {
    echo json_encode(["count" => 0]);
    exit;
}

$conn = (new DB_CONNECT())->connect();

/*
  Count upcoming appointments for BOTH:
  - owners
  - participants

  Owners are included because they also exist
  in appointment_participants with role='owner'
*/
$stmt = $conn->prepare("
    SELECT COUNT(DISTINCT a.id) AS count
    FROM appointments a
    JOIN appointment_participants ap
        ON ap.appointment_id = a.id
    WHERE ap.user_id = ?
      AND (
            a.appt_date > CURDATE()
            OR (a.appt_date = CURDATE() AND a.appt_time >= CURTIME())
          )
");

$stmt->bind_param("i", $user_id);
$stmt->execute();

$row = $stmt->get_result()->fetch_assoc();

echo json_encode([
    "count" => intval($row["count"] ?? 0)
]);
exit;
