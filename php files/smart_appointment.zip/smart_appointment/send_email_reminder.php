<?php
ob_start();
header("Content-Type: application/json");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . "/phpmailer/src/Exception.php";
require_once __DIR__ . "/phpmailer/src/PHPMailer.php";
require_once __DIR__ . "/phpmailer/src/SMTP.php";
require_once __DIR__ . "/db_connect.php";

/* =========================
   READ INPUT
   ========================= */
$data = json_decode(file_get_contents("php://input"), true);
$appointment_id = intval($data["appointment_id"] ?? 0);

if ($appointment_id <= 0) {
    echo json_encode([
        "success" => 0,
        "error" => "Invalid appointment ID"
    ]);
    exit;
}

/* =========================
   DB CONNECTION
   ========================= */
$conn = (new DB_CONNECT())->connect();

/* =========================
   FETCH PARTICIPANTS
   (NO email_sent usage)
   ========================= */
$stmt = $conn->prepare("
    SELECT
        u.email,
        u.username,
        a.title,
        a.location,
        a.notes,
        a.appt_date,
        a.appt_time
    FROM appointment_participants ap
    JOIN users u ON ap.user_id = u.id
    JOIN appointments a ON ap.appointment_id = a.id
    WHERE ap.appointment_id = ?
      AND a.email = 1
");
$stmt->bind_param("i", $appointment_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode([
        "success" => 0,
        "error" => "No participants found"
    ]);
    exit;
}

/* =========================
   MAILER SETUP
   ========================= */
$mail = new PHPMailer(true);

try {
    // SMTP
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    // $mail->Username   = 'smartappointmentapp123@gmail.com';
    // $mail->Password   = 'pqftqlwmihcpxxcd'; // Gmail App Password
    $mail->Username   = 'darrenleeqm@gmail.com';
    $mail->Password   = 'jljtymgctpcxeiji'; // Gmail App Password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    // Sender
    $mail->setFrom(
        // 'smartappointmentapp123@gmail.com',
        'darrenleeqm@gmail.com',
        'Smart Appointment'
    );
    $mail->addReplyTo(
        // 'smartappointmentapp123@gmail.com',
        'darrenleeqm@gmail.com',
        'Smart Appointment'
    );

    // UTF-8 safety
    $mail->CharSet  = 'UTF-8';
    $mail->Encoding = 'base64';

    $sentCount = 0;

    /* =========================
       SEND TO EACH PARTICIPANT
       ========================= */
    while ($row = $result->fetch_assoc()) {

        $email    = $row["email"];
        $username = !empty($row["username"])
            ? $row["username"]
            : "there";

        $time = date("h:i A", strtotime($row["appt_time"]));

        // Clear previous recipient
        $mail->clearAddresses();
        $mail->addAddress($email);

        // Subject
        $mail->Subject =
            "Your appointment on {$row['appt_date']} – {$row['title']}";

        // HTML body
        $mail->isHTML(true);
        $mail->Body = "
            <p>Hi {$username},</p>

            <p>This is a reminder for your upcoming appointment:</p>

            <ul>
                <li><strong>Title:</strong> {$row['title']}</li>
                <li><strong>Date:</strong> {$row['appt_date']}</li>
                <li><strong>Time:</strong> {$time}</li>
                <li><strong>Location:</strong> {$row['location']}</li>
            </ul>

            <p><strong>Notes:</strong><br>
            {$row['notes']}</p>

            <p>Best regards,<br>
            <strong>Smart Appointment</strong></p>
        ";

        // Plain-text fallback
        $mail->AltBody =
            "Hi {$username},\n\n" .
            "This is a reminder for your upcoming appointment:\n\n" .
            "Title: {$row['title']}\n" .
            "Date: {$row['appt_date']}\n" .
            "Time: {$time}\n" .
            "Location: {$row['location']}\n\n" .
            "Notes:\n{$row['notes']}\n\n" .
            "Smart Appointment";

        // Send
        $mail->send();
        $sentCount++;
    }

    echo json_encode([
        "success" => 1,
        "emails_sent" => $sentCount
    ]);
    exit;

} catch (Exception $e) {
    echo json_encode([
        "success" => 0,
        "error" => "Email send failed"
    ]);
    exit;
}

ob_end_clean();
