<?php
header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);
$id = intval($data["id"] ?? 0);

if ($id <= 0) {
    echo json_encode(["success" => 0]);
    exit;
}

$conn = (new DB_CONNECT())->connect();

$stmt = $conn->prepare(
    "SELECT notify, email, whatsapp
     FROM appointments
     WHERE id = ?"
);
$stmt->bind_param("i", $id);
$stmt->execute();

$row = $stmt->get_result()->fetch_assoc();

echo json_encode([
    "success" => 1,
    "data" => $row
]);
