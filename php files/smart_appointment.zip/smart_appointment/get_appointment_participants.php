<?php
header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);
$appointment_id = intval($data["appointment_id"] ?? 0);

if ($appointment_id <= 0) {
    echo json_encode(["success" => 0]);
    exit;
}

$conn = (new DB_CONNECT())->connect();

$stmt = $conn->prepare(
    "SELECT ap.user_id, u.username, ap.role
     FROM appointment_participants ap
     JOIN users u ON ap.user_id = u.id
     WHERE ap.appointment_id = ?"
);

$stmt->bind_param("i", $appointment_id);
$stmt->execute();

$res = $stmt->get_result();
$list = [];

while ($row = $res->fetch_assoc()) {
    $list[] = $row;
}

echo json_encode([
    "success" => 1,
    "data" => $list
]);
