<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Twilio\Rest\Client;

date_default_timezone_set("Asia/Singapore");
header("Content-Type: application/json; charset=UTF-8");

/* ================= HARD FAIL SAFETY ================= */
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

/* ================= METHOD CHECK ================= */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        "success" => 0,
        "message" => "POST only"
    ]);
    exit;
}

/* ================= DEPENDENCIES ================= */
require_once __DIR__ . "/phpmailer/src/Exception.php";
require_once __DIR__ . "/phpmailer/src/PHPMailer.php";
require_once __DIR__ . "/phpmailer/src/SMTP.php";
require_once __DIR__ . "/vendor/autoload.php";
require_once __DIR__ . "/db_connect.php";

/* ================= INPUT ================= */
$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

if (!is_array($data)) {
    echo json_encode([
        "success" => 0,
        "message" => "Invalid JSON"
    ]);
    exit;
}

$type   = trim($data["type"] ?? "");
$target = trim($data["target"] ?? "");

if ($type === "" || $target === "") {
    echo json_encode([
        "success" => 0,
        "message" => "Invalid request"
    ]);
    exit;
}

/* ================= NORMALIZE PHONE ================= */
if ($type === "phone") {
    $target = str_replace(" ", "", $target);
    if (substr($target, 0, 1) !== "+") {
        $target = "+65" . $target;
    }
}

/* ================= DB ================= */
$conn = (new DB_CONNECT())->connect();

/* ================= CLEAN EXPIRED ================= */
$conn->query("DELETE FROM otp_verification WHERE expires_at <= NOW()");

/* ================= BLOCK RESEND ================= */
$now = date("Y-m-d H:i:s");

$stmt = $conn->prepare(
    "SELECT id FROM otp_verification
     WHERE target=? AND type=? AND expires_at>?"
);
$stmt->bind_param("sss", $target, $type, $now);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo json_encode([
        "success" => 1,
        "message" => "OTP already sent. Please enter it."
    ]);
    exit;
}
$stmt->close();

/* ================= GENERATE OTP ================= */
$otp = random_int(100000, 999999);
$expires = date("Y-m-d H:i:s", time() + 30);

/* ================= STORE OTP ================= */
$stmt = $conn->prepare(
    "INSERT INTO otp_verification (target, type, otp_code, expires_at)
     VALUES (?, ?, ?, ?)"
);
$stmt->bind_param("ssss", $target, $type, $otp, $expires);
$stmt->execute();
$stmt->close();

/* ================= EMAIL ================= */
if ($type === "email") {
    try {
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = "smtp.gmail.com";
        $mail->SMTPAuth = true;
        // $mail->Username = "smartappointmentapp123@gmail.com";
        // $mail->Password = "ygzjimrhjmhcdyav";
        $mail->Username = "darrenleeqm@gmail.com";
        $mail->Password = "jljtymgctpcxeiji";
        $mail->SMTPSecure = "tls";
        $mail->Port = 587;

        // $mail->setFrom("smartappointmentapp123@gmail.com", "Smart Appointment");
        $mail->setFrom("darrenleeqm@gmail.com", "Smart Appointment");
        $mail->addAddress($target);

        $mail->Subject = "Email Verification Code";
        $mail->Body = "Your OTP is $otp\n\nExpires in 30 seconds.";

        $mail->send();

        echo json_encode(["success" => 1]);
        exit;
    } catch (Exception $e) {
        echo json_encode([
            "success" => 0,
            "message" => "Email send failed"
        ]);
        exit;
    }
}

/* ================= WHATSAPP ================= */
if ($type === "phone") {
    try {
        $twilio = new Client(
            "AC6214c8a2a7619732d15da81feec622b9",
            "d1495ef7778373d5f91702e35dab1c80"
        );

        $twilio->messages->create(
            "whatsapp:" . $target,
            [
                "from" => "whatsapp:+14155238886",
                "contentSid" => "HX229f5a04fd0510ce1b071852155d3e75",
                "contentVariables" => json_encode([
                    "1" => (string)$otp
                ])
            ]
        );

        echo json_encode(["success" => 1]);
        exit;
    } catch (Throwable $e) {
        echo json_encode([
            "success" => 0,
            "message" => "WhatsApp send failed"
        ]);
        exit;
    }
}

/* ================= FALLBACK ================= */
echo json_encode([
    "success" => 0,
    "message" => "Unsupported type"
]);
exit;
