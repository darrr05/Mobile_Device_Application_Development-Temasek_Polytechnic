<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);

// ================= INPUT =================
$user_id   = intval($data["user_id"] ?? 0);
$title     = trim($data["title"] ?? "");
$appt_date = trim($data["date"] ?? "");
$appt_time = trim($data["time"] ?? "");
$location  = trim($data["location"] ?? "");
$notes     = trim($data["notes"] ?? "");

$notify    = !empty($data["notify"]) ? 1 : 0;
$email     = !empty($data["email"]) ? 1 : 0;
$whatsapp  = !empty($data["whatsapp"]) ? 1 : 0;

$friends   = $data["friends"] ?? [];

// ================= VALIDATION =================
if ($user_id <= 0 || $title === "" || $appt_date === "" || $appt_time === "") {
    echo json_encode([
        "success" => 0,
        "message" => "Invalid input"
    ]);
    exit;
}

$conn = (new DB_CONNECT())->connect();
$conn->begin_transaction();

try {

    // ================= 1️⃣ INSERT APPOINTMENT =================
    $stmt = $conn->prepare(
        "INSERT INTO appointments
        (user_id, title, appt_date, appt_time, location, notes, status, notify, email, whatsapp)
        VALUES (?, ?, ?, ?, ?, ?, 'Scheduled', ?, ?, ?)"
    );

    $stmt->bind_param(
        "isssssiii",
        $user_id,
        $title,
        $appt_date,
        $appt_time,
        $location,
        $notes,
        $notify,
        $email,
        $whatsapp
    );

    $stmt->execute();
    $appointment_id = $conn->insert_id;

    // ================= 2️⃣ INSERT PARTICIPANTS (SAFE) =================
    $stmt = $conn->prepare(
        "INSERT IGNORE INTO appointment_participants
        (appointment_id, user_id, role)
        VALUES (?, ?, ?)"
    );

    // Owner
    $role = "owner";
    $stmt->bind_param("iis", $appointment_id, $user_id, $role);
    $stmt->execute();

    $allUsers = [$user_id];

    // Friends
    if (is_array($friends)) {
        foreach ($friends as $fid) {
            $fid = intval($fid);
            if ($fid <= 0) continue;
            if ($fid == $user_id) continue; // safety

            $role = "participant";
            $stmt->bind_param("iis", $appointment_id, $fid, $role);
            $stmt->execute();

            $allUsers[] = $fid;
        }
    }

    // ================= 3️⃣ IMMEDIATE EMAIL + WHATSAPP =================
    foreach ($allUsers as $uid) {

        $stmt = $conn->prepare(
            "SELECT email, phone FROM users WHERE id=?"
        );
        $stmt->bind_param("i", $uid);
        $stmt->execute();
        $u = $stmt->get_result()->fetch_assoc();

        if (!$u) continue;

        // 📧 Email immediately
        if ($email && !empty($u["email"])) {
            file_get_contents(
                "http://localhost/smart_appointment/send_email_reminder.php?appointment_id=$appointment_id"
            );
        }

        // 💬 WhatsApp immediately
        if ($whatsapp && !empty($u["phone"])) {
            file_get_contents(
                "http://localhost/smart_appointment/send_whatsapp_reminder.php?appointment_id=$appointment_id"
            );
        }
    }

    $conn->commit();

    echo json_encode([
        "success" => 1,
        "appointment_id" => $appointment_id
    ]);

} catch (Exception $e) {

    $conn->rollback();

    echo json_encode([
        "success" => 0,
        "message" => $e->getMessage()
    ]);
}
