<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

date_default_timezone_set("Asia/Singapore");
header("Content-Type: application/json; charset=UTF-8");

/* ================= ERROR HANDLING ================= */
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

/* ================= METHOD CHECK ================= */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        "success" => 0,
        "message" => "POST only"
    ]);
    exit;
}

/* ================= DEPENDENCIES ================= */
require_once __DIR__ . "/phpmailer/src/Exception.php";
require_once __DIR__ . "/phpmailer/src/PHPMailer.php";
require_once __DIR__ . "/phpmailer/src/SMTP.php";
require_once __DIR__ . "/vendor/autoload.php";
require_once __DIR__ . "/db_connect.php";

/* ================= INPUT ================= */
$data = json_decode(file_get_contents("php://input"), true);
$email = strtolower(trim($data["email"] ?? ""));

if ($email === "") {
    echo json_encode([
        "success" => 0,
        "message" => "Email required"
    ]);
    exit;
}

/* ================= DB CONNECT ================= */
$conn = (new DB_CONNECT())->connect();

/* ================= CLEAN EXPIRED OTP ================= */
$conn->query("DELETE FROM otp_verification WHERE expires_at <= NOW()");

/* ================= CHECK USER ================= */
$stmt = $conn->prepare(
    "SELECT id, google_id, password_hash
     FROM users
     WHERE LOWER(email)=?
     LIMIT 1"
);
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($user_id, $google_id, $password_hash);

if (!$stmt->fetch()) {
    echo json_encode([
        "success" => 0,
        "message" => "Account not found"
    ]);
    exit;
}
$stmt->close(); // ✅ VERY IMPORTANT

/* ================= BLOCK GOOGLE USERS ================= */
if (!empty($google_id) || empty($password_hash)) {
    echo json_encode([
        "success" => 0,
        "message" => "Google users cannot reset password"
    ]);
    exit;
}

/* ================= BLOCK OTP RESEND ================= */
$type = "reset";
$now  = date("Y-m-d H:i:s");

$block = $conn->prepare(
    "SELECT id
     FROM otp_verification
     WHERE target=? AND type=? AND expires_at>?"
);
$block->bind_param("sss", $email, $type, $now);
$block->execute();
$block->store_result();

if ($block->num_rows > 0) {
    echo json_encode([
        "success" => 1,
        "message" => "OTP already sent"
    ]);
    exit;
}
$block->close();

/* ================= GENERATE OTP ================= */
$otp = random_int(100000, 999999);
$expires = date("Y-m-d H:i:s", time() + 30);

/* ================= STORE OTP ================= */
$ins = $conn->prepare(
    "INSERT INTO otp_verification (target, type, otp_code, expires_at, user_id)
     VALUES (?, ?, ?, ?, ?)"
);
$ins->bind_param("ssssi", $email, $type, $otp, $expires, $user_id);
$ins->execute();
$ins->close();

/* ================= SEND EMAIL ================= */
try {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host       = "smtp.gmail.com";
    $mail->SMTPAuth   = true;
    $mail->Username   = "darrenleeqm@gmail.com";
    $mail->Password   = "jljtymgctpcxeiji"; // Gmail App Password
    $mail->SMTPSecure = "tls";
    $mail->Port       = 587;

    $mail->setFrom("darrenleeqm@gmail.com", "Smart Appointment");
    $mail->addAddress($email);
    $mail->Subject = "Reset Password OTP";
    $mail->Body    = "Your OTP is $otp\n\nExpires in 30 seconds.";

    $mail->send();

    echo json_encode([
        "success" => 1
    ]);
    exit;

} catch (Throwable $e) {
    echo json_encode([
        "success" => 0,
        "message" => "Email send failed"
    ]);
    exit;
}
