<?php
header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);

$appointment_id = intval($data["id"] ?? 0);
$user_id        = intval($data["user_id"] ?? 0);

if ($appointment_id <= 0 || $user_id <= 0) {
    echo json_encode(["success" => 0, "message" => "Invalid input"]);
    exit;
}

$conn = (new DB_CONNECT())->connect();
$conn->begin_transaction();

try {

    /* ================= VERIFY OWNER ================= */
    $stmt = $conn->prepare(
        "SELECT 1
         FROM appointment_participants
         WHERE appointment_id = ?
           AND user_id = ?
           AND role = 'owner'"
    );
    $stmt->bind_param("ii", $appointment_id, $user_id);
    $stmt->execute();

    if ($stmt->get_result()->num_rows === 0) {
        throw new Exception("Unauthorized");
    }

    /* ================= DELETE PARTICIPANTS ================= */
    $stmt = $conn->prepare(
        "DELETE FROM appointment_participants
         WHERE appointment_id = ?"
    );
    $stmt->bind_param("i", $appointment_id);
    $stmt->execute();

    /* ================= DELETE APPOINTMENT ================= */
    $stmt = $conn->prepare(
        "DELETE FROM appointments
         WHERE id = ?"
    );
    $stmt->bind_param("i", $appointment_id);
    $stmt->execute();

    if ($stmt->affected_rows === 0) {
        throw new Exception("Appointment not found");
    }

    $conn->commit();

    echo json_encode([
        "success" => 1,
        "message" => "Appointment and participants deleted"
    ]);

} catch (Exception $e) {

    $conn->rollback();

    echo json_encode([
        "success" => 0,
        "message" => $e->getMessage()
    ]);
}
