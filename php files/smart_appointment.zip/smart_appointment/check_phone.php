<?php
header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);
$phone = trim($data["phone"] ?? "");

if ($phone === "") {
    echo json_encode(["available" => 0]);
    exit;
}

$conn = (new DB_CONNECT())->connect();

$stmt = $conn->prepare("SELECT id FROM users WHERE phone = ?");
$stmt->bind_param("s", $phone);
$stmt->execute();
$stmt->store_result();

echo json_encode([
    "available" => $stmt->num_rows === 0 ? 1 : 0
]);
