<?php
header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);
$user_id = intval($data["user_id"] ?? 0);

if ($user_id <= 0) {
    echo json_encode(["success" => 0]);
    exit;
}

$conn = (new DB_CONNECT())->connect();
$result = [];

/* ===== ACCEPTED FRIENDS ===== */
$stmt = $conn->prepare(
    "SELECT 
        u.id,
        u.username,
        'Accepted' AS status,
        NULL AS direction
     FROM friends f
     JOIN users u ON u.id = f.friend_id
     WHERE f.user_id = ?"
);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $result[] = $row;
}

/* ===== INCOMING PENDING ===== */
$stmt = $conn->prepare(
    "SELECT 
        u.id,
        u.username,
        'Pending' AS status,
        'incoming' AS direction
     FROM friend_requests fr
     JOIN users u ON u.id = fr.sender_id
     WHERE fr.receiver_id = ?
       AND fr.status = 'pending'"
);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $result[] = $row;
}

/* ===== OUTGOING PENDING ===== */
$stmt = $conn->prepare(
    "SELECT 
        u.id,
        u.username,
        'Pending' AS status,
        'outgoing' AS direction
     FROM friend_requests fr
     JOIN users u ON u.id = fr.receiver_id
     WHERE fr.sender_id = ?
       AND fr.status = 'pending'"
);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $result[] = $row;
}

echo json_encode([
    "success" => 1,
    "data" => $result
]);
