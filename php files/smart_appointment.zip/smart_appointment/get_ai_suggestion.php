<?php
header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);
$appointment_id = intval($data["appointment_id"] ?? 0);

if ($appointment_id <= 0) {
    echo json_encode(["success" => 0, "message" => "Invalid appointment"]);
    exit;
}

$conn = (new DB_CONNECT())->connect();

$stmt = $conn->prepare(
    "SELECT title, appt_date, appt_time, location, notes
     FROM appointments
     WHERE id = ?"
);
$stmt->bind_param("i", $appointment_id);
$stmt->execute();

$appt = $stmt->get_result()->fetch_assoc();

if (!$appt) {
    echo json_encode(["success" => 0, "message" => "Appointment not found"]);
    exit;
}

$timestamp = strtotime($appt["appt_date"] . " " . $appt["appt_time"]);
$isOverdue = $timestamp < time();

$suggestions = [];

if ($isOverdue) {
    $suggestions[] = "• Review what was completed";
    $suggestions[] = "• Note any follow-up actions";
    $suggestions[] = "• Save important details or receipts";
    $suggestions[] = "• Schedule a new appointment if needed";
} else {
    $suggestions[] = "• Prepare required items or documents";
    $suggestions[] = "• Arrive 10 minutes early";
    $suggestions[] = "• Double-check the location";
    $suggestions[] = "• Set reminders if needed";
}

if (!empty($appt["notes"])) {
    $suggestions[] = "• Review your notes before the appointment";
}

$responseText = implode("\n", $suggestions);

echo json_encode([
    "success" => 1,
    "ai_response" => $responseText
]);
