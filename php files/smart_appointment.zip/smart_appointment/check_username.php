<?php
header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);
$username = trim($data["username"] ?? "");

if ($username === "") {
    echo json_encode([
        "available" => 0,
        "message" => "Empty username"
    ]);
    exit;
}

$conn = (new DB_CONNECT())->connect();

$stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo json_encode([
        "available" => 0
    ]);
} else {
    echo json_encode([
        "available" => 1
    ]);
}
