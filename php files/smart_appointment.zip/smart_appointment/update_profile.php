<?php
header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);

$user_id  = intval($data["user_id"] ?? 0);
$username = trim($data["username"] ?? "");
$phoneRaw = trim($data["phone"] ?? "");

$phone = $phoneRaw === "" ? null : $phoneRaw;

if ($user_id <= 0 || $username === "") {
    echo json_encode(["success" => 0, "message" => "Invalid input"]);
    exit;
}

$conn = (new DB_CONNECT())->connect();

/* ===== Username must be unique (except self) ===== */
$stmt = $conn->prepare(
    "SELECT id FROM users WHERE username = ? AND id != ?"
);
$stmt->bind_param("si", $username, $user_id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo json_encode([
        "success" => 0,
        "message" => "username exists"
    ]);
    exit;
}
$stmt->close();

/* ===== Phone must be unique (except self) ===== */
if ($phone !== null) {
    $stmt = $conn->prepare(
        "SELECT id FROM users WHERE phone = ? AND id != ?"
    );
    $stmt->bind_param("si", $phone, $user_id);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo json_encode([
            "success" => 0,
            "message" => "phone exists"
        ]);
        exit;
    }
    $stmt->close();
}

/* ===== Update profile ===== */
$stmt = $conn->prepare(
    "UPDATE users
     SET username = ?,
         phone = ?,
         phone_verified = IF(phone = ?, phone_verified, 0)
     WHERE id = ?"
);
$stmt->bind_param("sssi", $username, $phone, $phone, $user_id);

if ($stmt->execute()) {
    echo json_encode(["success" => 1]);
} else {
    echo json_encode([
        "success" => 0,
        "message" => "Update failed"
    ]);
}

$stmt->close();
$conn->close();
