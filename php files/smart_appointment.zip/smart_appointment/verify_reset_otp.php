<?php
date_default_timezone_set("Asia/Singapore");
header("Content-Type: application/json; charset=UTF-8");

require_once __DIR__ . "/db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);
$email = strtolower(trim($data["email"] ?? ""));
$otp   = trim($data["otp"] ?? "");

if ($email === "" || $otp === "") {
    echo json_encode(["success" => 0, "message" => "Invalid request"]);
    exit;
}

$conn = (new DB_CONNECT())->connect();
$now = date("Y-m-d H:i:s");
$type = "reset";

$stmt = $conn->prepare(
    "SELECT id, user_id
     FROM otp_verification
     WHERE target=? AND type=? AND otp_code=? AND expires_at>?
     LIMIT 1"
);
$stmt->bind_param("ssss", $email, $type, $otp, $now);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();

if (!$row) {
    echo json_encode(["success" => 0, "message" => "Invalid or expired OTP"]);
    exit;
}

$otp_id = intval($row["id"]);
$user_id = intval($row["user_id"]);

$del = $conn->prepare("DELETE FROM otp_verification WHERE id=?");
$del->bind_param("i", $otp_id);
$del->execute();

$reset_token = bin2hex(random_bytes(32)); // send to app
$token_hash = password_hash($reset_token, PASSWORD_DEFAULT);
$expires = date("Y-m-d H:i:s", time() + 600); // 10 min

$conn->query("DELETE FROM password_reset_tokens WHERE user_id=" . $user_id);

$ins = $conn->prepare(
    "INSERT INTO password_reset_tokens (user_id, token_hash, expires_at) VALUES (?,?,?)"
);
$ins->bind_param("iss", $user_id, $token_hash, $expires);
$ins->execute();

echo json_encode(["success" => 1, "reset_token" => $reset_token]);
exit;
